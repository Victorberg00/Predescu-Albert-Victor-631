<?php
// Verificăm dacă formularul a fost trimis
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username']; // Preluăm numele de utilizator din formular
    $password = $_POST['password']; // Preluăm parola din formular

    // Script pentru autentificarea utilizatorului folosind LocalStorage
    echo "
    <script>
        // Preluăm utilizatorii din LocalStorage
        let users = JSON.parse(localStorage.getItem('users')) || [];
        // Căutăm utilizatorul care are numele și parola furnizate
        let user = users.find(user => user.username === '$username' && user.password === '$password');
        if (user) {
            alert('Login successful'); // Mesaj de succes la autentificare
            window.location.href = 'index.php'; // Redirecționăm către pagina principală
        } else {
            alert('Invalid credentials'); // Mesaj de eroare dacă datele sunt greșite
        }
    </script>
    ";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css"> <!-- Legătura către fișierul CSS -->
    <title>Login</title>
</head>
<body>
    <header>
        <h1>Login</h1>
    </header>
    <main>
        <!-- Formular pentru autentificare -->
        <form method="POST" action="">
            <label for="username">Username:</label>
            <input type="text" id="username" name="username" required> <!-- Câmp pentru numele de utilizator -->
            <br>
            <label for="password">Password:</label>
            <input type="password" id="password" name="password" required> <!-- Câmp pentru parolă -->
            <br>
            <button type="submit">Login</button> <!-- Buton pentru trimiterea formularului -->
        </form>
    </main>
</body>
</html>
