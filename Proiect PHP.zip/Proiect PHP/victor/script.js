const movies = [
    {
        title: "Inception",
        description: "A skilled thief, the absolute best in the dangerous art of 'extraction', stealing valuable secrets from deep within the subconscious during the dream state...",
        image: "https://th.bing.com/th/id/OIP.fYLXgLBnnbp3N8JCRuUIGAHaLH?rs=1&pid=ImgDetMain",
        discount: false
    },
    {
        title: "The Matrix",
        description: "A computer hacker learns from mysterious rebels about the true nature of his reality and his role in the war against its controllers...",
        image: "https://picfiles.alphacoders.com/385/385304.jpg",
        discount: true
    },
    {
        title: "Interstellar",
        description: "With Earth facing extinction, a group of explorers venture beyond the solar system in search of a new habitable planet...",
        image: "https://th.bing.com/th/id/OIP.uiaj_IMaC7h3NoieAhcmVwHaLG?rs=1&pid=ImgDetMain",
        discount: false
    },
    {
        title: "The Dark Knight",
        description: "Batman faces a new threat in the form of the Joker, a criminal mastermind who seeks to create chaos in Gotham City...",
        image: "https://th.bing.com/th/id/OIP.NN9rKH-vZbFgtH4FuoW7OwHaLH?rs=1&pid=ImgDetMain",
        discount: true
    }
];

let wishlist = JSON.parse(localStorage.getItem('wishlist')) || [];
let favorites = JSON.parse(localStorage.getItem('favorites')) || [];

function renderMovies() {
    const movieGrid = document.getElementById('movieGrid');
    movieGrid.innerHTML = '';

    movies.forEach(movie => {
        const movieCard = document.createElement('div');
        movieCard.classList.add('movie-card');
        
        const movieImage = document.createElement('img');
        movieImage.src = movie.image;
        movieImage.alt = movie.title;
        
        const movieTitle = document.createElement('h3');
        movieTitle.textContent = movie.title;
        
        const movieDescription = document.createElement('p');
        movieDescription.textContent = movie.description;
        
        const addToWishlistButton = document.createElement('button');
        addToWishlistButton.textContent = 'Add to Wishlist';
        addToWishlistButton.onclick = () => addToWishlist(movie);

        movieCard.append(movieImage, movieTitle, movieDescription, addToWishlistButton);
        
        if (movie.discount) {
            const discountBadge = document.createElement('span');
            discountBadge.textContent = 'Discount Available!';
            movieCard.append(discountBadge);
        }

        movieGrid.append(movieCard);
    });
}

function addToWishlist(movie) {
    if (!wishlist.some(item => item.title === movie.title)) {
        wishlist.push(movie);
        localStorage.setItem('wishlist', JSON.stringify(wishlist));
        alert(`${movie.title} added to your wishlist!`);
    }
}

function showWishlist() {
    alert('Wishlist: ' + wishlist.map(item => item.title).join(', '));
}

function showFavorites() {
    alert('Favorites: ' + favorites.map(item => item.title).join(', '));
}

renderMovies();
