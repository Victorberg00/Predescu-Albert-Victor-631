<?php
// Verificăm dacă formularul a fost trimis
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username']; // Preluăm numele de utilizator din formular
    $password = $_POST['password']; // Preluăm parola din formular

    // Script pentru salvarea utilizatorului în LocalStorage
    echo "
    <script>
        // Preluăm utilizatorii din LocalStorage sau creăm un array nou
        let users = JSON.parse(localStorage.getItem('users')) || [];
        // Adăugăm utilizatorul nou
        users.push({username: '$username', password: '$password'});
        // Salvăm utilizatorii actualizați în LocalStorage
        localStorage.setItem('users', JSON.stringify(users));
        alert('Registration successful'); // Afișăm un mesaj de succes
        window.location.href = 'login.php'; // Redirecționăm către pagina de autentificare
    </script>
    ";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css"> <!-- Legătura către fișierul CSS -->
    <title>Register</title>
</head>
<body>
    <header>
        <h1>Register</h1>
    </header>
    <main>
        <!-- Formular pentru înregistrare -->
        <form method="POST" action="">
            <label for="username">Username:</label>
            <input type="text" id="username" name="username" required> <!-- Câmp pentru numele de utilizator -->
            <br>
            <label for="password">Password:</label>
            <input type="password" id="password" name="password" required> <!-- Câmp pentru parolă -->
            <br>
            <button type="submit">Register</button> <!-- Buton pentru trimiterea formularului -->
        </form>
    </main>
</body>
</html>
