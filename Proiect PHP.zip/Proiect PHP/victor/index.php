<?php
// Începem sesiunea pentru a stoca informații despre utilizator
session_start();

// Array-ul cu informații despre filme
$movies = [
    ["title" => "Inception", "description" => "A skilled thief, the absolute best in the dangerous art of 'extraction', stealing valuable secrets from deep within the subconscious during the dream state, is offered a chance to have his criminal history erased. In exchange, he must implant an idea into a CEO's mind. But the mission becomes complicated as he faces unexpected challenges.", "discount" => false, "image" => "images/inception.jpg"],
    ["title" => "The Matrix", "description" => "A computer hacker learns from mysterious rebels about the true nature of his reality and his role in the war against its controllers. A mind-bending journey full of action, deception, and high-stakes philosophy.", "discount" => true, "image" => "images/matrix.jpg"],
    ["title" => "Interstellar", "description" => "With Earth facing extinction, a group of explorers venture beyond the solar system in search of a new habitable planet. Using a newly discovered wormhole, they attempt to transcend space-time and make an impossible journey to save humanity.", "discount" => false, "image" => "images/interstellar.jpg"],
    ["title" => "The Dark Knight", "description" => "Batman faces a new threat in the form of the Joker, a criminal mastermind who seeks to create chaos in Gotham City. As he battles the Joker's plans, Batman must question his own values and morality.", "discount" => true, "image" => "images/dark_knight.jpg"],
    ["title" => "Avengers: Endgame", "description" => "After the devastating events of Avengers: Infinity War, the Avengers assemble once more to undo Thanos' actions and restore balance to the universe. The ultimate battle for the fate of the universe begins.", "discount" => false, "image" => "images/endgame.jpg"],
    ["title" => "Parasite", "description" => "The Kims, a poor family, become entangled with the wealthy Parks, a series of events leading to unexpected twists and dark revelations that blur the lines between class and morality.", "discount" => true, "image" => "images/parasite.jpg"]
];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css"> <!-- Legătura către fișierul CSS pentru stilizare -->
    <title>Movie List</title>
</head>
<body>
    <header>
        <div class="logo">
            <h1>Movie Mania</h1>
        </div>
        <nav>
            <a href="login.php">Login</a>
            <a href="register.php">Register</a>
            <a href="wishlist.php">Wishlist</a>
            <a href="favorites.php">Favorites</a>
            <a href="discounts.php">Discounts</a>
        </nav>
    </header>
    <main>
        <section id="movies">
            <h2>Featured Movies</h2>
            <div class="movie-grid">
                <?php 
                // Afișăm fiecare film din array-ul de filme
                foreach ($movies as $movie): ?>
                    <div class="movie-card">
                        <div class="movie-image-container">
                            <img src="<?php echo $movie['image']; ?>" alt="<?php echo $movie['title']; ?>" class="movie-image">
                            <?php if ($movie['discount']): ?>
                                <span class="discount-badge">Discount Available!</span>
                            <?php endif; ?>
                        </div>
                        <div class="movie-details">
                            <h3 class="movie-title"><?php echo $movie['title']; ?></h3>
                            <p class="movie-description"><?php echo $movie['description']; ?></p>
                            <form method="POST" action="wishlist.php">
                                <input type="hidden" name="movie" value="<?php echo $movie['title']; ?>">
                                <button type="submit" class="wishlist-button">Add to Wishlist</button>
                            </form>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </section>
    </main>
</body>
</html>
