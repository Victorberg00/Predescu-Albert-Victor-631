// Register Logic
document.getElementById('registerForm')?.addEventListener('submit', function (event) {
    event.preventDefault();
    
    const username = document.getElementById('newUsername').value;
    const password = document.getElementById('newPassword').value;
    
    if (username && password) {
        localStorage.setItem('user', JSON.stringify({ username, password }));
        alert('Registration successful!');
        window.location.href = 'login.html'; // Redirect to login page
    }
});

// Login Logic
document.getElementById('authForm')?.addEventListener('submit', function (event) {
    event.preventDefault();
    
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;
    
    const storedUser = JSON.parse(localStorage.getItem('user'));
    
    if (storedUser && storedUser.username === username && storedUser.password === password) {
        alert('Login successful!');
        window.location.href = 'index.html'; // Redirect to main page
    } else {
        alert('Invalid credentials. Please try again.');
    }
});
